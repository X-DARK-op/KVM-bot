"""Local QEMU/KVM VM backend for the UnixNodes Discord bot. No panel API."""
import asyncio, json, os, re, secrets, shlex, socket, subprocess, time
from pathlib import Path

ROOT = Path(os.getenv('QEMU_VPS_DIR', '/var/lib/unixnodes-qemu'))
VMROOT = ROOT / 'vms'
CACHE = ROOT / 'images'
STATE = ROOT / 'state.json'
for p in (VMROOT, CACHE): p.mkdir(parents=True, exist_ok=True)

OS_IMAGES = {
 'ubuntu:20.04': ('focal', 'https://cloud-images.ubuntu.com/focal/current/focal-server-cloudimg-amd64.img'),
 'ubuntu:22.04': ('jammy', 'https://cloud-images.ubuntu.com/jammy/current/jammy-server-cloudimg-amd64.img'),
 'ubuntu:24.04': ('noble', 'https://cloud-images.ubuntu.com/noble/current/noble-server-cloudimg-amd64.img'),
 'images:debian/10': ('debian10', 'https://cloud.debian.org/images/cloud/buster/latest/debian-10-genericcloud-amd64.qcow2'),
 'images:debian/11': ('bullseye', 'https://cloud.debian.org/images/cloud/bullseye/latest/debian-11-genericcloud-amd64.qcow2'),
 'images:debian/12': ('bookworm', 'https://cloud.debian.org/images/cloud/bookworm/latest/debian-12-genericcloud-amd64.qcow2'),
 'images:debian/13': ('trixie', 'https://cloud.debian.org/images/cloud/trixie/latest/debian-13-genericcloud-amd64.qcow2'),
}

def _load():
    try: return json.loads(STATE.read_text())
    except Exception: return {}
def _save(data):
    tmp=STATE.with_suffix('.tmp'); tmp.write_text(json.dumps(data, indent=2)); tmp.replace(STATE)
def _safe(name):
    name=re.sub(r'[^A-Za-z0-9_.-]', '-', str(name)).strip('-.')[:48]
    if not name: raise ValueError('Invalid VM name')
    return name
def _run(args, timeout=120, check=True):
    p=subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=timeout)
    if check and p.returncode: raise RuntimeError((p.stderr or p.stdout or f'Command failed: {args[0]}').strip())
    return p.stdout.strip()
def _free_port():
    state=_load(); used={int(x.get('ssh_port',0)) for x in state.values()}
    for port in range(22000, 30000):
        if port in used: continue
        with socket.socket() as s:
            try: s.bind(('0.0.0.0', port)); return port
            except OSError: pass
    raise RuntimeError('No available SSH forwarding port in 22000-29999')
def _image(os_version):
    key=os_version if os_version in OS_IMAGES else None
    if key is None: raise RuntimeError(f'Unsupported OS image: {os_version}. Supported: {", ".join(OS_IMAGES)}')
    slug,url=OS_IMAGES[key]; target=CACHE / (slug + Path(url).suffix)
    if not target.exists() or target.stat().st_size < 1024*1024:
        tmp=target.with_suffix(target.suffix+'.part')
        _run(['wget','-q','--show-progress','-O',str(tmp),url],timeout=1800)
        if tmp.stat().st_size < 1024*1024: tmp.unlink(missing_ok=True); raise RuntimeError('Downloaded OS image is too small')
        tmp.replace(target)
    return target

def _pid(vm):
    try: return int((Path(vm['dir'])/'qemu.pid').read_text().strip())
    except Exception: return None
def _running(vm):
    p=_pid(vm)
    if not p: return False
    try: os.kill(p,0); return True
    except OSError: return False

async def create_vm(name, os_version='ubuntu:22.04', timeout=120):
    name=_safe(name); state=_load()
    if name in state or (VMROOT/name).exists(): raise RuntimeError(f'VM {name} already exists')
    base=await asyncio.to_thread(_image,os_version); d=VMROOT/name; d.mkdir(parents=True)
    password=secrets.token_urlsafe(14); port=_free_port(); disk=d/'disk.qcow2'
    # A backing image keeps provisioning fast and saves disk space.
    await asyncio.to_thread(_run,['qemu-img','create','-f','qcow2','-F','qcow2','-b',str(base),str(disk),'20G'],timeout=timeout)
    (d/'user-data').write_text(f'''#cloud-config\nhostname: {name}\nmanage_etc_hosts: true\ndisable_root: false\nssh_pwauth: true\nusers:\n  - name: root\n    lock_passwd: false\n    passwd: "{password}"\nchpasswd:\n  expire: false\n  users:\n    - name: root\n      password: "{password}"\n      type: text\nwrite_files:\n  - path: /etc/ssh/sshd_config.d/99-unixnodes.conf\n    permissions: '0644'\n    content: |\n      PermitRootLogin yes\n      PasswordAuthentication yes\n      KbdInteractiveAuthentication no\n      UsePAM yes\nruncmd:\n  - systemctl restart ssh || systemctl restart sshd || true\n''')
    (d/'meta-data').write_text(f'instance-id: {name}\nlocal-hostname: {name}\n')
    await asyncio.to_thread(_run,['cloud-localds',str(d/'seed.iso'),str(d/'user-data'),str(d/'meta-data')],timeout=timeout)
    state[name]={'name':name,'dir':str(d),'os':os_version,'memory_mb':2048,'cpus':2,'disk':'20G','ssh_port':port,'password':password,'created':int(time.time())}
    _save(state)
    return f'Created QEMU VM {name} (SSH port {port})'

async def set_config(name, memory=None, cpus=None, disk=None):
    name=_safe(name); state=_load()
    if name not in state: raise RuntimeError(f'QEMU VM {name} not found')
    vm=state[name]
    if memory is not None:
        m=re.search(r'\d+',str(memory)); vm['memory_mb']=int(m.group()) if m else int(memory)
    if cpus is not None: vm['cpus']=max(1,int(cpus))
    if disk is not None:
        size=str(disk).upper()
        await asyncio.to_thread(_run,['qemu-img','resize',str(Path(vm['dir'])/'disk.qcow2'),size],timeout=120,check=False)
        vm['disk']=size
    _save(state); return True

async def start_vm(name, timeout=120):
    name=_safe(name); state=_load()
    if name not in state: raise RuntimeError(f'QEMU VM {name} not found')
    vm=state[name]
    if _running(vm): return 'already running'
    d=Path(vm['dir']); args=['qemu-system-x86_64','-name',name,'-m',str(vm.get('memory_mb',2048)),'-smp',str(vm.get('cpus',2)),'-machine','q35,accel=kvm:tcg','-cpu','host','-drive',f'file={d}/disk.qcow2,format=qcow2,if=virtio','-drive',f'file={d}/seed.iso,format=raw,if=virtio,media=cdrom','-boot','order=c','-device','virtio-net-pci,netdev=n0','-netdev',f'user,id=n0,hostfwd=tcp:0.0.0.0:{vm["ssh_port"]}-:22','-display','none','-serial',f'file:{d}/boot.log','-pidfile',str(d/'qemu.pid'),'-daemonize','-no-reboot']
    if not (Path('/dev/kvm').exists() and os.access('/dev/kvm', os.R_OK | os.W_OK)):
        args[args.index('q35,accel=kvm:tcg')]='q35,accel=tcg'; args[args.index('host')]='qemu64'
    await asyncio.to_thread(_run,args,timeout=timeout)
    return f'QEMU VM {name} started; SSH port {vm["ssh_port"]}'

async def stop_vm(name, timeout=60):
    name=_safe(name); state=_load(); vm=state.get(name)
    if not vm: raise RuntimeError(f'QEMU VM {name} not found')
    pid=_pid(vm)
    if pid:
        try: os.kill(pid,15)
        except OSError: pass
        for _ in range(max(1,timeout*2)):
            if not _running(vm): break
            await asyncio.sleep(.5)
        if _running(vm):
            try: os.kill(pid,9)
            except OSError: pass
    return f'QEMU VM {name} stopped'

async def delete_vm(name):
    name=_safe(name); state=_load()
    if name not in state: return True
    await stop_vm(name)
    import shutil
    shutil.rmtree(state[name]['dir'],ignore_errors=True); state.pop(name,None); _save(state)
    return f'Deleted QEMU VM {name}'

async def exec_guest(name, command, timeout=120):
    name=_safe(name); state=_load(); vm=state.get(name)
    if not vm: raise RuntimeError(f'QEMU VM {name} not found')
    if not _running(vm): raise RuntimeError(f'QEMU VM {name} is not running')
    # Wait for cloud-init/SSH on first boot.
    last=None
    for _ in range(min(timeout,150)):
        try:
            import paramiko
            client=paramiko.SSHClient(); client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            client.connect('127.0.0.1',port=int(vm['ssh_port']),username='root',password=vm['password'],timeout=3,auth_timeout=3,banner_timeout=3,allow_agent=False,look_for_keys=False)
            try:
                stdin,stdout,stderr=client.exec_command(command,timeout=timeout)
                out=stdout.read().decode(errors='replace'); err=stderr.read().decode(errors='replace'); code=stdout.channel.recv_exit_status()
                if code: raise RuntimeError(err or out or f'Guest command exit code {code}')
                # Track password updates made by configure_ssh's chpasswd command.
                m=re.search(r"root:([^'\s]+)['\"]?\s*\|\s*chpasswd",command)
                if m: vm['password']=m.group(1); _save(state)
                return out.strip() or True
            finally: client.close()
        except Exception as e:
            last=e; await asyncio.sleep(1)
    raise RuntimeError(f'SSH not ready for {name} on host port {vm["ssh_port"]}: {last}')

async def list_vms():
    state=_load()
    return '\n'.join(f'{n}\t{("RUNNING" if _running(v) else "STOPPED")}\t{v.get("memory_mb")}MB\t{v.get("cpus")} CPU\tSSH:{v.get("ssh_port")}' for n,v in state.items()) or 'No QEMU VMs found'
async def info_vm(name):
    state=_load(); vm=state.get(_safe(name))
    if not vm: raise RuntimeError(f'QEMU VM {name} not found')
    return json.dumps({'name':name,'status':'running' if _running(vm) else 'stopped','os':vm.get('os'),'memory_mb':vm.get('memory_mb'),'cpus':vm.get('cpus'),'disk':vm.get('disk'),'ssh_port':vm.get('ssh_port')},indent=2)
