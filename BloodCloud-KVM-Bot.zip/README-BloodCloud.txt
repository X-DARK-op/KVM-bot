BloodCloud QEMU/KVM Discord Bot bundle
======================================

Files:
- bot-qemu.py       Discord bot (legacy command layer translated to local QEMU backend)
- qemu_backend.py   QEMU VM creation/start/stop/delete, cloud-init root password and SSH setup
- webssh.html       User-supplied xterm.js Web SSH interface, now included in the install
- install-qemu-bot.sh
- .env.example

Install on a Debian/Ubuntu KVM host:
1. Extract the ZIP.
2. Copy .env.example to .env and fill in DISCORD_TOKEN, MAIN_ADMIN_ID,
   YOUR_SERVER_IP and WEBSSH_SERVER_IP.
3. Run as root from the extracted directory:
   bash install-qemu-bot.sh "$PWD"
4. Copy your configured .env to /opt/unixnodes-bot/.env:
   install -m 600 .env /opt/unixnodes-bot/.env
5. Start manually:
   /opt/unixnodes-bot/run.sh

The bot generates a unique random root password per VM and cloud-init enables
SSH password authentication. Credentials are then updated in the bot's VPS data.
Supported cloud images are Ubuntu 20.04/22.04/24.04 and Debian 10/11/12/13.
QEMU uses KVM acceleration if /dev/kvm is accessible; otherwise TCG software
emulation is used and will be much slower.

Important limitations:
- This is a partial conversion of the supplied legacy bot. Core local VM
  provisioning/lifecycle operations use QEMU, but some older monitoring,
  networking, port-forward, and remote-node commands may still rely on LXC and
  require further conversion before being treated as production-ready.
- The Web SSH page is served by Flask on WEBSSH_PORT. Keep the endpoint behind
  HTTPS and access controls before exposing it publicly. Do not use a shared
  root password for public VMs.
- Test on a non-production host before replacing an existing bot.
