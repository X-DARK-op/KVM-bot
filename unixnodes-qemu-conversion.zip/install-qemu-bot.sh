#!/usr/bin/env bash
set -Eeuo pipefail

# Install the patched Discord bot backend locally. This does NOT install or call vPanel APIs.
# Usage from the directory containing bot-qemu.py and qemu_backend.py:
#   sudo bash install-qemu-bot.sh /path/to/current/bot-folder

SRC_DIR="${1:-$PWD}"
BOT_FILE="$SRC_DIR/bot-qemu.py"
BACKEND_FILE="$SRC_DIR/qemu_backend.py"
TARGET_DIR="${BOT_INSTALL_DIR:-/opt/unixnodes-bot}"

[[ $EUID -eq 0 ]] || { echo 'Run as root: sudo bash install-qemu-bot.sh'; exit 1; }
[[ -f "$BOT_FILE" ]] || { echo "Missing $BOT_FILE"; exit 1; }
[[ -f "$BACKEND_FILE" ]] || { echo "Missing $BACKEND_FILE"; exit 1; }

export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y python3 python3-venv python3-pip qemu-system-x86 qemu-utils cloud-image-utils wget curl openssh-client

# KVM is optional; QEMU TCG emulation is used if /dev/kvm isn't accessible.
if [[ -e /dev/kvm && -r /dev/kvm && -w /dev/kvm ]]; then
  echo '[OK] /dev/kvm is accessible; hardware acceleration should be available.'
else
  echo '[WARN] /dev/kvm is not accessible. VMs can use software emulation but will be slower.'
fi

mkdir -p "$TARGET_DIR" /var/lib/unixnodes-qemu/vms /var/lib/unixnodes-qemu/images
chmod 750 /var/lib/unixnodes-qemu
if [[ -f "$TARGET_DIR/bot.py" ]]; then
  cp -a "$TARGET_DIR/bot.py" "$TARGET_DIR/bot.py.backup.$(date +%Y%m%d-%H%M%S)"
fi
install -m 750 "$BOT_FILE" "$TARGET_DIR/bot.py"
install -m 640 "$BACKEND_FILE" "$TARGET_DIR/qemu_backend.py"

# Use a virtual environment so system Python packages aren't overwritten.
python3 -m venv "$TARGET_DIR/venv"
"$TARGET_DIR/venv/bin/pip" install --upgrade pip
"$TARGET_DIR/venv/bin/pip" install discord.py python-dotenv requests paramiko flask flask-cors

cat > "$TARGET_DIR/run.sh" <<EOF
#!/usr/bin/env bash
cd "$TARGET_DIR"
exec "$TARGET_DIR/venv/bin/python" "$TARGET_DIR/bot.py"
EOF
chmod 750 "$TARGET_DIR/run.sh"

cat <<EOF

Install files placed in: $TARGET_DIR
Start manually with:
  $TARGET_DIR/run.sh

Make sure your existing .env file (especially DISCORD_TOKEN and MAIN_ADMIN_ID) is copied to:
  $TARGET_DIR/.env

QEMU VM data/images: /var/lib/unixnodes-qemu
No panel, HTTP API, Docker, or MongoDB is used by this bot backend.
IMPORTANT: This converts the local provisioning/lifecycle command layer to QEMU. LXC-only features
such as LXC profiles, container network devices, and remote LXC nodes do not have a direct QEMU
translation and need separate implementation. Test with a non-production bot first.
EOF
